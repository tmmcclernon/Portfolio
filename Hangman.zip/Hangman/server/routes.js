//Author: Nnamdi Nwanze
//Description: This routes module creates custom routes and demonstrates the use of routes using the database manager module

var express = require('express');
var router = express.Router();
//use database manager module
var mydb = require('./dbmgr.js');

//use the url module
const url = require('url');


//setup route /
router.get('/', function (req, res) {
    res.send(JSON.stringify('Welcome to the main page'));
});
router.post('/username',function(req,res){
    username = (req.body)
    res.send("adding username to database")
   
    console.log("this is the username: "+ JSON.stringify(username))
    //store unique usernames in database
    mydb.findRec(username,mydb.insertIfNotFound(username))
    mydb.findAll(1000,{username:'Trippe'})
    
});
//setup route /player1
router.get('/player1', function (req, res) {
    res.send('sending json object of p1 stats');
});
//setup route /player2
router.get('/player2', function(req,res){
    res.send('json stats for player2:')
});
//setup route /highscorres
router.get('/highscores', function(res,req){
    res.send("Welcome to the highscores page")
});
//Setup database, only need to run this once. Unblock to run once then block this line again
//mydb.setup();
//mydb.deleteCollection();







module.exports = router;